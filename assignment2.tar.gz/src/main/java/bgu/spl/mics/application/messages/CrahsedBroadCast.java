package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.objects.Pose;

import java.util.List;

public class CrahsedBroadCast implements Broadcast {
}
