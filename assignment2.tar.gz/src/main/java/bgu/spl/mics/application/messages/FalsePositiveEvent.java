package bgu.spl.mics.application.messages;

import bgu.spl.mics.EventImp;

public class FalsePositiveEvent extends EventImp {
    public FalsePositiveEvent(String SenderId) {
        super(SenderId);
    }
}
