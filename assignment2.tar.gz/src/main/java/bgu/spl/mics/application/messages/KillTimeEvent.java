package bgu.spl.mics.application.messages;

import bgu.spl.mics.EventImp;

public class KillTimeEvent extends EventImp {
    public KillTimeEvent(String SenderId) {
        super(SenderId);
    }
}
